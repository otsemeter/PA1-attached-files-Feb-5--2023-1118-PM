#include "sequence.h"
#include<stdlib.h>
#include<stdio.h>

static int log_2(int n)
{
    int logn = 0;

    while(n > 1)
    {
        n /= 2;
        logn++;
    }
    return logn;
}
long *Generate_2p3q_Seq(int n, int *seq_size)
{
    int i = 0;
    int ind2 = 0;
    int ind3 = 0;
    int curr2 = 1;
    int curr3 = 1;
    int log_n;
    if(n <= 1)
    {
        long* seq_2p3q= (long*)malloc(sizeof(long) * (*seq_size));
        return seq_2p3q;
    }

    log_n = log_2(n);
    (*seq_size) = log_n * log_n;
    long *seq_2p3q = (long*)malloc(sizeof(long) * (*seq_size));
    seq_2p3q[0] = 1;
    while(seq_2p3q[i] < n)
    {
        i++;
        curr2 = seq_2p3q[ind2] * 2;
        curr3 = seq_2p3q[ind3] * 3;
        (curr2 <= curr3)? (seq_2p3q[i] = curr2): (seq_2p3q[i] = curr3);
        ind2 += (curr2 <= curr3);
        ind3 += (curr3 <= curr2);
    }
    *seq_size = i;

    return seq_2p3q;
    
}